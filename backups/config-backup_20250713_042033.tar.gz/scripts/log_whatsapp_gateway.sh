#!/bin/bash
echo "📄 Mostrando logs en tiempo real del gateway WhatsApp..."
pm2 logs mailton-whatsapp
