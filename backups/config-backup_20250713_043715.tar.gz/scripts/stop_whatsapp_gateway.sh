#!/bin/bash
echo "🛑 Deteniendo gateway WhatsApp..."
pm2 stop mailton-whatsapp
