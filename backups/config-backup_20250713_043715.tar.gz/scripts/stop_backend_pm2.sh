#!/bin/bash

echo "🛑 Deteniendo backend FastAPI de Mailton Kanazo..."
pm2 stop mailton-backend
